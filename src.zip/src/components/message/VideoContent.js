import { useState } from 'react';
import { View, TouchableOpacity, Image, StyleSheet, ActivityIndicator } from 'react-native';
import { Video, ResizeMode } from 'expo-av';
import { Ionicons } from '@expo/vector-icons';
import { toDisplayUrl } from '../../utils/imageUrl';
import { UploadOverlay } from './UploadOverlay';
import { styles } from './styles';

export function VideoContent({ msg, onImagePress, uploadProgress }) {
  const [playing, setPlaying] = useState(false);
  const [isBuffering, setIsBuffering] = useState(false);
  const url = msg.media.url;

  if (!playing) {
    return (
      <TouchableOpacity activeOpacity={0.85} onPress={() => !msg.isPending && setPlaying(true)} disabled={msg.isPending}>
        <View style={[styles.mediaImage, styles.videoThumb, { position: 'relative' }]}>
          {msg.media.thumbnail || msg.media.low ? (
            <Image source={{ uri: toDisplayUrl(msg.media.thumbnail || msg.media.low) }} style={StyleSheet.absoluteFill} resizeMode="cover" />
          ) : null}
          {!msg.isPending && (
            <View style={styles.playBadge}>
              <Ionicons name="play" size={26} color="#fff" />
            </View>
          )}
          {msg.isPending && <UploadOverlay progress={uploadProgress} />}
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      activeOpacity={1}
      onLongPress={() => onImagePress?.({ url, media: msg.media, mediaType: 'video' })}
    >
      <View style={[styles.mediaImage, { position: 'relative', overflow: 'hidden', backgroundColor: '#000' }]}>
        <Video
          source={{ uri: url }}
          style={StyleSheet.absoluteFill}
          useNativeControls
          resizeMode={ResizeMode.CONTAIN}
          shouldPlay={true}
          onPlaybackStatusUpdate={(status) => {
            if (status.isLoaded) {
              setIsBuffering(status.isBuffering);
            } else if (status.error) {
              setIsBuffering(false);
            } else {
              setIsBuffering(true);
            }
          }}
        />
        {isBuffering && (
          <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(0,0,0,0.3)', alignItems: 'center', justifyContent: 'center' }]}>
            <ActivityIndicator size="large" color="#fff" />
          </View>
        )}
      </View>
    </TouchableOpacity>
  );
}
